# 清屏（QingPing）0.1.0

原生 Android Kotlin MVP，minSdk 29（Android 10），无 Root。

## 当前实现
- 用户手动授权并启动 `VpnService`。
- VPN 只路由虚拟 DNS 服务器 `10.111.0.1/32`，普通网络流量不进入 TUN。
- 解析 IPv4/UDP DNS 查询；匹配内置域名后返回 NXDOMAIN；其他 DNS 查询经 `protect()` 后转发到 `1.1.1.1:53`。
- SQLite 保存域名、时间、拦截结果和尽力识别的来源应用 UID；界面显示累计拦截、按应用统计、最近 100 条历史。

## 已知限制（请先读）
- 这是 DNS 过滤 MVP，不是完整的全流量 VPN；不处理 IPv6 DNS、TCP DNS/DoT/DoH、DNS over HTTPS、非 DNS 广告请求或普通流量转发。
- 域名列表只是演示用的少量规则，可能误拦截/漏拦截；不要把“DNS 过滤次数”理解为“所有开屏广告被拦截次数”。
- Android 不保证 `getConnectionOwnerUid()` 能对每个虚拟 DNS 流稳定返回来源 UID，因此部分记录会显示“无法识别的应用”。按 APP 统计只对成功归属的记录准确。
- 上游 DNS 固定为 Cloudflare `1.1.1.1`，使用普通 UDP/53，不加密；可按需修改为可信解析器或实现 DoT。
- 强制停止、部分厂商后台管理或系统策略仍可能停止服务。可在系统 VPN 设置里查看是否支持“始终开启 VPN”；本 MVP 不会绕过系统限制。
- 未实现自动更新规则、应用白名单、IPv6、DoH/DoT 检测、开机广播自动拉起、完整流量转发和可靠的逐 APP 归属。

## 导入与构建
1. 安装 Android Studio（建议稳定版）和 JDK 17。
2. 解压 ZIP，在 Android Studio 选择 **Open**，选中包含 `settings.gradle.kts` 的 `QingPing` 文件夹。
3. 等待 Gradle Sync；确保 Android SDK Platform 35 和 Build Tools 可用。
4. 连接 Android 10+ 设备，开启开发者选项与 USB 调试。
5. 选择 `app` 配置，点击 Run。首次开启时在系统 VPN 授权对话框中同意。
6. 生成 APK：`Build > Build Bundle(s) / APK(s) > Build APK(s)`。调试 APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 建议测试
- 启动过滤后，浏览器访问普通 HTTPS 网站，确认普通流量仍可访问。
- 用 DNS 测试工具查询 `example.com`，确认普通域名可解析。
- 查询 `doubleclick.net` 或 `googleadservices.com`，检查是否出现拦截记录；不同应用可能使用缓存或加密 DNS，因此不一定经过此过滤器。
- 关闭服务后确认 DNS 查询恢复到系统默认解析路径。
- 测试飞行模式切换、Wi-Fi/移动网络切换、VPN 撤销授权、强制停止、重启设备等情况。
- 在 Android 10、Android 13/14/15 等设备上分别验证通知与前台服务行为。

## 权限
- `INTERNET`：向上游 DNS 服务器发送查询。
- `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_SPECIAL_USE`：维持用户可见的过滤服务通知（Android 14+ 需特别声明服务类型）。
- `POST_NOTIFICATIONS`：Android 13+ 通知权限；拒绝通知权限不等同于授权 VPN。
- `BIND_VPN_SERVICE` 作为 Service 的权限声明，不是要求用户在设置里手动授予的普通权限。

## 安全提示
本地 VPN 会接管被路由进 TUN 的 DNS 数据包。此版本只对 DNS 进行处理，不上传日志；但会向配置的上游 DNS 发送未命中的查询域名。请仅在你信任的设备和网络上测试。

## 不在本机安装 Android Studio 的构建方式（GitHub Actions）

本仓库包含 `.github/workflows/build-apk.yml`。将整个 `qingping` 文件夹中的内容上传到你自己的 GitHub 仓库后：

1. 打开仓库的 **Actions** 页面。
2. 选择 **Build QingPing APK**。
3. 点击 **Run workflow**，再点击绿色的 **Run workflow** 确认。
4. 等待工作流完成，打开成功的运行记录，在页面底部的 **Artifacts** 下载 `QingPing-debug-apk`。
5. 解压下载的 artifact，得到 `app-debug.apk`，传到安卓手机安装。

这是调试签名 APK，适合个人测试。GitHub Actions 需要联网下载 Gradle 与 Android SDK；本地构建环境若无网络，不能在离线状态下完成首次构建。

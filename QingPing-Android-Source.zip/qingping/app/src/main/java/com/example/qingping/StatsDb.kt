package com.example.qingping

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class EventRow(
    val id: Long,
    val time: Long,
    val packageName: String,
    val appLabel: String,
    val domain: String,
    val blocked: Boolean,
    val note: String
)

data class AppStat(val packageName: String, val appLabel: String, val count: Int)

class StatsDb(context: Context) : SQLiteOpenHelper(context, "qingping.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            time INTEGER NOT NULL,
            package_name TEXT NOT NULL,
            app_label TEXT NOT NULL,
            domain TEXT NOT NULL,
            blocked INTEGER NOT NULL,
            note TEXT NOT NULL
        )""".trimIndent())
        db.execSQL("CREATE INDEX idx_events_time ON events(time DESC)")
        db.execSQL("CREATE INDEX idx_events_package ON events(package_name)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized fun add(packageName: String, appLabel: String, domain: String, blocked: Boolean, note: String) {
        val values = ContentValues().apply {
            put("time", System.currentTimeMillis())
            put("package_name", packageName)
            put("app_label", appLabel)
            put("domain", domain)
            put("blocked", if (blocked) 1 else 0)
            put("note", note)
        }
        writableDatabase.insert("events", null, values)
    }

    @Synchronized fun appStats(): List<AppStat> {
        val result = mutableListOf<AppStat>()
        readableDatabase.rawQuery(
            "SELECT package_name, app_label, COUNT(*) FROM events WHERE blocked=1 GROUP BY package_name, app_label ORDER BY COUNT(*) DESC",
            null
        ).use { c -> while (c.moveToNext()) result += AppStat(c.getString(0), c.getString(1), c.getInt(2)) }
        return result
    }

    @Synchronized fun history(limit: Int = 100): List<EventRow> {
        val result = mutableListOf<EventRow>()
        readableDatabase.rawQuery(
            "SELECT id,time,package_name,app_label,domain,blocked,note FROM events ORDER BY time DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) result += EventRow(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4), c.getInt(5) == 1, c.getString(6))
        }
        return result
    }

    @Synchronized fun blockedTotal(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM events WHERE blocked=1", null).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 0
        }
    }
}

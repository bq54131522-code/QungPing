package com.example.qingping

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.system.OsConstants
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "com.example.qingping.START"
        const val ACTION_STOP = "com.example.qingping.STOP"
        const val ACTION_STATUS = "com.example.qingping.STATUS"
        const val EXTRA_RUNNING = "running"
        private const val CHANNEL = "qingping_vpn"
        private const val NOTIFICATION_ID = 4107
        private const val TAG = "QingPingVPN"
        private const val VPN_ADDR = "10.111.0.2"
        private const val DNS_ADDR = "10.111.0.1"
        private const val UPSTREAM_DNS = "1.1.1.1"
        private val blockedSuffixes = listOf(
            "doubleclick.net", "googleadservices.com", "googlesyndication.com",
            "adservice.google.com", "adnxs.com", "adform.net", "adcolony.com",
            "applovin.com", "unityads.unity3d.com"
        )
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    private lateinit var db: StatsDb

    override fun onCreate() {
        super.onCreate()
        db = StatsDb(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopFiltering()
            ACTION_START, null -> startFiltering()
        }
        return START_STICKY
    }

    private fun startFiltering() {
        if (running.get()) return
        startForeground(NOTIFICATION_ID, buildNotification())
        try {
            val pfd = Builder()
                .setSession("清屏 DNS 过滤")
                .setMtu(1500)
                .addAddress(VPN_ADDR, 32)
                .addDnsServer(DNS_ADDR)
                // 只把虚拟 DNS 服务器地址路由进 TUN；普通网络流量不走 VPN。
                .addRoute(DNS_ADDR, 32)
                .establish()
            if (pfd == null) {
                broadcastStatus(false)
                stopSelf()
                return
            }
            tun = pfd
            running.set(true)
            broadcastStatus(true)
            worker = Thread({ packetLoop(pfd) }, "QingPing-DNS").apply { start() }
        } catch (e: Exception) {
            Log.e(TAG, "Cannot establish VPN", e)
            broadcastStatus(false)
            stopSelf()
        }
    }

    private fun stopFiltering() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        worker?.interrupt()
        worker = null
        broadcastStatus(false)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun packetLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32767)
        try {
            while (running.get()) {
                val size = input.read(buffer)
                if (size <= 0) continue
                val packet = buffer.copyOf(size)
                try {
                    val parsed = parseDnsPacket(packet) ?: continue
                    val (dnsQuery, domain, qtype) = parsed
                    val blocked = blockedSuffixes.any { domain == it || domain.endsWith(".$it") }
                    val owner = findOwner(packet)
                    val appLabel = owner.second
                    val packageName = owner.first
                    val dnsResponse = if (blocked) makeBlockedResponse(dnsQuery, qtype) else forwardDns(dnsQuery)
                    if (dnsResponse != null) {
                        val responsePacket = buildUdpIpv4Response(packet, dnsResponse)
                        synchronized(output) { output.write(responsePacket); output.flush() }
                    }
                    if (blocked) {
                        db.add(packageName, appLabel, domain, true, "已拦截 DNS（NXDOMAIN）")
                    } else {
                        db.add(packageName, appLabel, domain, false, "DNS 已转发")
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Ignored malformed/unsupported packet", e)
                }
            }
        } catch (e: Exception) {
            if (running.get()) Log.e(TAG, "Packet loop stopped", e)
        } finally {
            running.set(false)
            broadcastStatus(false)
        }
    }

    private data class ParsedDns(val query: ByteArray, val domain: String, val qtype: Int)

    private fun parseDnsPacket(packet: ByteArray): ParsedDns? {
        if (packet.size < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0xF
        if (version != 4) return null // MVP 暂不处理 IPv6 DNS
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (ihl < 20 || packet.size < ihl + 8) return null
        if ((packet[9].toInt() and 0xFF) != OsConstants.IPPROTO_UDP) return null
        val fragment = u16(packet, 6)
        if ((fragment and 0x1FFF) != 0) return null
        val srcPort = u16(packet, ihl)
        val dstPort = u16(packet, ihl + 2)
        if (dstPort != 53) return null
        val udpLength = u16(packet, ihl + 4)
        if (udpLength < 8 || packet.size < ihl + udpLength) return null
        val dns = packet.copyOfRange(ihl + 8, ihl + udpLength)
        if (dns.size < 17) return null
        val qdCount = u16(dns, 4)
        if (qdCount < 1) return null
        var i = 12
        val labels = mutableListOf<String>()
        while (i < dns.size) {
            val len = dns[i++].toInt() and 0xFF
            if (len == 0) break
            if ((len and 0xC0) != 0 || len > 63 || i + len > dns.size) return null
            labels += String(dns, i, len, Charsets.US_ASCII)
            i += len
        }
        if (i + 4 > dns.size || labels.isEmpty()) return null
        val qtype = u16(dns, i)
        return ParsedDns(dns, labels.joinToString(".").lowercase(), qtype)
    }

    private fun makeBlockedResponse(query: ByteArray, qtype: Int): ByteArray {
        val response = query.copyOf()
        response[2] = 0x81.toByte()
        // QR=1, RD=1, RA=1, RCODE=3 (NXDOMAIN); zero answer/authority/additional counts.
        response[3] = 0x83.toByte()
        response[6] = 0; response[7] = 0
        response[8] = 0; response[9] = 0
        response[10] = 0; response[11] = 0
        return response
    }

    private fun forwardDns(query: ByteArray): ByteArray? {
        var socket: DatagramSocket? = null
        return try {
            socket = DatagramSocket()
            protect(socket)
            socket.soTimeout = 2500
            val address = InetAddress.getByName(UPSTREAM_DNS)
            socket.send(DatagramPacket(query, query.size, address, 53))
            val buf = ByteArray(4096)
            val reply = DatagramPacket(buf, buf.size)
            socket.receive(reply)
            buf.copyOf(reply.length)
        } catch (e: Exception) {
            Log.w(TAG, "DNS upstream unavailable", e)
            null
        } finally { socket?.close() }
    }

    private fun buildUdpIpv4Response(request: ByteArray, dns: ByteArray): ByteArray {
        val ihl = (request[0].toInt() and 0xF) * 4
        val src = request.copyOfRange(12, 16)
        val dst = request.copyOfRange(16, 20)
        val srcPort = u16(request, ihl)
        val dstPort = u16(request, ihl + 2)
        val udpLen = 8 + dns.size
        val totalLen = 20 + udpLen
        val out = ByteArray(totalLen)
        out[0] = 0x45
        out[1] = 0
        put16(out, 2, totalLen)
        put16(out, 4, u16(request, 4))
        put16(out, 6, 0x4000)
        out[8] = 64
        out[9] = OsConstants.IPPROTO_UDP.toByte()
        System.arraycopy(dst, 0, out, 12, 4)
        System.arraycopy(src, 0, out, 16, 4)
        put16(out, 10, checksum(out, 0, 20))
        put16(out, 20, dstPort)
        put16(out, 22, srcPort)
        put16(out, 24, udpLen)
        put16(out, 26, 0) // IPv4 UDP checksum is optional.
        System.arraycopy(dns, 0, out, 28, dns.size)
        return out
    }

    @Suppress("DEPRECATION")
    private fun findOwner(packet: ByteArray): Pair<String, String> {
        return try {
            val ihl = (packet[0].toInt() and 0xF) * 4
            val srcIp = InetAddress.getByAddress(packet.copyOfRange(12, 16))
            val dstIp = InetAddress.getByAddress(packet.copyOfRange(16, 20))
            val srcPort = u16(packet, ihl)
            val dstPort = u16(packet, ihl + 2)
            val uid = getConnectionOwnerUid(
                OsConstants.IPPROTO_UDP,
                InetSocketAddress(srcIp, srcPort),
                InetSocketAddress(dstIp, dstPort)
            )
            if (uid < 0) return Pair("unknown", "无法识别的应用")
            val packages = packageManager.getPackagesForUid(uid).orEmpty()
            val pkg = packages.firstOrNull() ?: "uid:$uid"
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
            Pair(pkg, label)
        } catch (_: Exception) { Pair("unknown", "无法识别的应用") }
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length) {
            val hi = data[i].toInt() and 0xFF
            val lo = if (i + 1 < offset + length) data[i + 1].toInt() and 0xFF else 0
            sum += (hi shl 8) or lo
            i += 2
        }
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv().toInt() and 0xFFFF
    }

    private fun u16(a: ByteArray, i: Int): Int = ((a[i].toInt() and 0xFF) shl 8) or (a[i + 1].toInt() and 0xFF)
    private fun put16(a: ByteArray, i: Int, value: Int) { a[i] = (value ushr 8).toByte(); a[i + 1] = value.toByte() }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "清屏过滤服务", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL).setContentTitle("清屏正在运行")
                .setContentText("本地 DNS 广告过滤已启用")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("清屏正在运行").setContentText("本地 DNS 广告过滤已启用")
                .setSmallIcon(android.R.drawable.ic_lock_lock).setContentIntent(open).setOngoing(true).build()
        }
    }

    private fun broadcastStatus(isRunning: Boolean) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_RUNNING, isRunning))
    }

    override fun onRevoke() {
        stopFiltering()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopFiltering()
        super.onDestroy()
    }
}

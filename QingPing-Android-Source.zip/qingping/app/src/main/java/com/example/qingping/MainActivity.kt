package com.example.qingping

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: StatsDb
    private lateinit var status: TextView
    private lateinit var summary: TextView
    private lateinit var list: TextView
    private var running = false

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            running = intent?.getBooleanExtra(DnsVpnService.EXTRA_RUNNING, false) ?: false
            render()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = StatsDb(this)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 300)
        }
        val filter = IntentFilter(DnsVpnService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(statusReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, filter)
        }
        render()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(16))
            setBackgroundColor(0xFFF7F8F5.toInt())
        }
        val title = TextView(this).apply { text = "清屏"; textSize = 30f; setTextColor(0xFF193D32.toInt()); gravity = Gravity.START }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "本地 DNS 广告过滤 · Android 10+"
            textSize = 14f; setTextColor(0xFF68756F.toInt()); setPadding(0, dp(4), 0, dp(16))
        }
        root.addView(subtitle, matchWrap())
        status = TextView(this).apply { textSize = 17f; setTextColor(0xFF193D32.toInt()); setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status, matchWrap())
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text = "开启过滤"; setOnClickListener { requestVpn() } }, LinearLayout.LayoutParams(0, dp(52), 1f))
        actions.addView(Button(this).apply { text = "停止过滤"; setOnClickListener { startService(Intent(this@MainActivity, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP)) } }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(actions, matchWrap())
        summary = TextView(this).apply { textSize = 19f; setTextColor(0xFF193D32.toInt()); setPadding(0, dp(22), 0, dp(8)) }
        root.addView(summary, matchWrap())
        root.addView(TextView(this).apply { text = "按应用统计（仅统计成功识别来源的记录会归属具体 APP）"; textSize = 14f; setTextColor(0xFF68756F.toInt()); setPadding(0, dp(4), 0, dp(6)) }, matchWrap())
        val scroll = ScrollView(this)
        list = TextView(this).apply { textSize = 14f; setTextColor(0xFF27332E.toInt()); setPadding(0, dp(4), 0, dp(12)); setTextIsSelectable(true) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val refresh = Button(this).apply { text = "刷新统计与历史"; setOnClickListener { render() } }
        root.addView(refresh, matchWrap())
        setContentView(root)
    }

    private fun requestVpn() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) startActivityForResult(prepare, 100) else startVpnService()
    }

    @Deprecated("Deprecated in Android API; kept for broad API 29+ compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) startVpnService()
    }

    private fun startVpnService() {
        val intent = Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_START)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun render() {
        val total = db.blockedTotal()
        status.text = if (running) "● 过滤服务运行中" else "○ 过滤服务未运行"
        summary.text = "累计拦截：$total 次"
        val out = StringBuilder()
        val stats = db.appStats()
        if (stats.isEmpty()) out.append("暂无已拦截记录。\n")
        stats.forEachIndexed { index, row ->
            out.append("${index + 1}. ${row.appLabel}\n   ${row.packageName}\n   拦截 ${row.count} 次\n\n")
        }
        out.append("\n最近历史（最多 100 条）\n──────────────────\n")
        val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault())
        db.history().forEach { e ->
            out.append(fmt.format(Date(e.time))).append("  ")
                .append(if (e.blocked) "已拦截" else "已转发").append("\n")
                .append(e.domain).append("\n")
                .append(e.appLabel).append(" · ").append(e.note).append("\n\n")
        }
        list.text = out.toString()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onResume() { super.onResume(); render() }
    override fun onDestroy() {
        try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
